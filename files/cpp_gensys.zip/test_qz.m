% Callum Jones
% tests the C++ version of the qz decomposition against Matlab's

GAM0 = [5 7 ; -2 -4] ;
GAM1 = [1 3 ; -4 -9] ;

[A, B, Q, Z, VV]=qz(GAM0,GAM1);
[A, B, Q, Z, VV]=ordqz(A,B,Q,Z,'udo');

[A_, B_, Q_, Z_] = qz_(GAM0,GAM1) ;

Q*A*Z %should give GAM0
Q*B*Z %should give GAM1

Q_*A_*ctranspose(Z_) %should give GAM0
Q_*B_*ctranspose(Z_) %should give GAM1

%% Examples with RE model

% model_ produces model's structural matrices
model_ 

%%%%
% Old gensys
%%%%
[S0_A, S1_A, S2_A, ~, ~, ~, ~, ~] = ...
    gensys(C, GAM0, GAM1, PSI, PPI) ;

%%%%
% New gensys, with Matlab's ordqz - works really well
%%%%
[A, B, Q, Z, VV] = qz(GAM0,GAM1);
[A, B, Q, Z, VV] = ordqz(A,B,Q,Z,'udo');

%%%%
% Example with C++ qz function
%%%%

% Note that Q has to go in transposed, because the output of zgges is
% organized differently from the output of Matlab's qz
[S0_C, S1_C, S2_C, ~, ~, ~, ~, ~] = ...
    gensys_(C, GAM0, GAM1, PSI, PPI) ;

%% IRF

shock = randn(4,1) ;

x_A = zeros(n,1) + S2_A*shock ;
%x_B = zeros(n,1) + S2_B*shock ;
x_C = zeros(n,1) + S2_C*shock ;

for tt=2:20
    x_A(:,tt) = S0_A + S1_A*x_A(:,tt-1) ;
    %x_B(:,tt) = S0_B + S1_B*x_B(:,tt-1) ;
    x_C(:,tt) = S0_C + S1_C*x_C(:,tt-1) ;
end
    
figure; 
subplot(3,1,1) ; hold on; 
plot(x_A(pi,:),'k','LineWidth',4); 
%plot(x_B(pi,:),'--r','LineWidth',4); 
plot(x_C(pi,:),'og','LineWidth',4); 
title('Inflation') ;
grid on
box on
legend('gensys','gensys\_ (C++ impl.)') ;
subplot(3,1,2) ; hold on; 
plot(x_A(r,:),'k','LineWidth',4); 
%plot(x_B(r,:),'--r','LineWidth',4); 
plot(x_C(r,:),'og','LineWidth',4);
title('Interest rate') ;
grid on
box on
subplot(3,1,3) ; hold on; 
plot(x_A(x,:),'k','LineWidth',4); 
%plot(x_B(x,:),'--r','LineWidth',4); 
plot(x_C(x,:),'og','LineWidth',4); 
title('Output gap') ;
grid on
box on 
set(findall(gcf,'-property','FontSize'),'FontSize',13) ;
%print -depsc ./latex/irf.eps
%close