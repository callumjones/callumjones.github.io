// Callum Jones
// callum.jones@nyu.edu
#include "mex.h"
#include "f2c.h"
#include "stdio.h"
#include "clapack.h"
#include "ord_eig.h"
#include "string.h"

doublecomplex* mat2cmpl(const mxArray *X, int ldz, int ndz);
mxArray* cmpl2mat(doublecomplex *Z, int ldz, int m, int n);
mxArray* cmpl2mat_real(doublecomplex *Z, int ldz, int m, int n);

extern logical order_eigs(doublecomplex* alpha,  doublecomplex* beta) ;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    doublecomplex  *GAM0, *GAM1 ;
    
    mwSignedIndex n, m, p, q; 
    
    n       = (mwSignedIndex)mxGetN(prhs[0]); // Cols of GAM0
    m       = (mwSignedIndex)mxGetM(prhs[0]); // Rows of GAM0
    p       = (mwSignedIndex)mxGetN(prhs[1]); // Cols of GAM1
    q       = (mwSignedIndex)mxGetM(prhs[1]); // Rows of GAM1
    integer n_int = (int)n ;
    
    if (nrhs != 2) {
        mexErrMsgTxt("Function requires two input matrices.");
    }
    
    if (n != m && m != p && p != q) {
        mexErrMsgTxt("Matrices should be square and of same dimension.");
    }
    
    // For inputting into dgges
    char JOBVSL     = 'V' ; 
	char JOBVSR     = 'V' ; 
	char SORT       = 'S' ;
	doublecomplex* alpha = new doublecomplex[n_int];
	doublecomplex* beta  = new doublecomplex[n_int];
	doublecomplex* matZ  = new doublecomplex[n_int*n_int];
	doublecomplex* matQ  = new doublecomplex[n_int*n_int];
	integer info, sdim ;
	integer lwork = -1 ;
	doublecomplex work_query;
    doublereal* rwork = new doublereal[8*n_int] ;
	logical* bwork    = new logical[n_int];

	GAM0 = mat2cmpl(prhs[0],n,n);
    GAM1 = mat2cmpl(prhs[1],n,n);
    matZ = (doublecomplex*)mxCalloc(n*n,sizeof(doublecomplex));
    matQ = (doublecomplex*)mxCalloc(n*n,sizeof(doublecomplex));
    
    // Call zgges_
	zgges_(
		&JOBVSL, &JOBVSR, &SORT, (L_fp)order_eigs, 
		&n_int, GAM0, &n_int, GAM1, &n_int,
		&sdim, alpha, beta, matQ, &n_int,
		matZ, &n_int, &work_query, &lwork, rwork, bwork, &info );

    lwork = (int)(work_query.r);
	doublecomplex* work = new doublecomplex[lwork];
	
	zgges_(
		&JOBVSL, &JOBVSR, &SORT, (L_fp)order_eigs, 
		&n_int, GAM0, &n_int, GAM1, &n_int,
		&sdim, alpha, beta, matQ, &n_int,
		matZ, &n_int, work, &lwork, rwork, bwork, &info );  
     
	plhs[0]  = mxCreateDoubleMatrix(n, n, mxCOMPLEX);
    plhs[1]  = mxCreateDoubleMatrix(n, n, mxCOMPLEX);
    plhs[2]  = mxCreateDoubleMatrix(n, n, mxCOMPLEX);
    plhs[3]  = mxCreateDoubleMatrix(n, n, mxCOMPLEX);
    
    plhs[0] = cmpl2mat(GAM0, n, n, n);
    plhs[1] = cmpl2mat(GAM1, n, n, n);
    plhs[2] = cmpl2mat(matQ, n, n, n);
    plhs[3] = cmpl2mat(matZ, n, n, n);
    
    mxFree(GAM0) ;
    mxFree(GAM1) ;
    mxFree(matQ) ;
    mxFree(matZ) ;   
}

/*
 * Convert MATLAB complex matrix to MKL complex storage.
 *
 *          Z = mat2cmpl(X,ldz,ndz)
 *
 * converts MATLAB's mxArray X to doublecomplex Z(ldz,ndz).
 * The parameters ldz and ndz determine the storage allocated for Z,
 * while mxGetM(X) and mxGetN(X) determine the amount of data copied.
 * 
 * Credit: Iskander Karibzhanov
 */
doublecomplex* mat2cmpl(const mxArray *X, int ldz, int ndz) {
   doublecomplex *Z, *zp;
   int m, n, incz, cmplxflag;
   register int i, j;
   double *xr, *xi;

   Z = (doublecomplex*)mxCalloc(ldz*ndz, sizeof(doublecomplex));
   xr = mxGetPr(X);
   xi = mxGetPi(X);
   m =  (int)mxGetM(X);
   n =  (int)mxGetN(X);
   zp = Z;
   incz = ldz-m;
   cmplxflag = (xi != NULL);
   for (j = 0; j < n; j++) {
      if (cmplxflag) {
         for (i = 0; i < m; i++) {
            zp->r = *xr++;
            zp->i = *xi++;
            zp++;
         }
      } else {
         for (i = 0; i < m; i++) {
            zp->r = *xr++;
            zp++;
         }
      }
      zp += incz;
   }
   return(Z);
}

/*
 * Convert MKL complex storage to MATLAB real and imaginary parts.
 *
 *          X = mkl2mat(Z,ldz,m,n)
 *
 * copies doublecomplex Z to X, producing a complex mxArray
 * with mxGetM(X) = m and mxGetN(X) = n.
 *
 * Credit: Iskander Karibzhanov
 */
mxArray* cmpl2mat(doublecomplex *Z, int ldz, int m, int n) {
   int i, j, incz;
   double *xr, *xi;
   doublecomplex *zp;
   mxArray *X;

   X = mxCreateDoubleMatrix(m,n,mxCOMPLEX);
   xr = mxGetPr(X);
   xi = mxGetPi(X);
   zp = Z;
   incz = ldz-m;
   for (j = 0; j < n; j++) {
      for (i = 0; i < m; i++) {
         *xr++ = zp->r;
         *xi++ = zp->i;
         zp++;
      }
      zp += incz;
   }
   return(X);
}

/*
 * Convert MKL complex storage to MATLAB real matrix ignoring imaginary part.
 *
 *          X = mkl2mat(Z,ldz,m,n)
 *
 * copies doublecomplex Z to X, producing a real mxArray
 * with mxGetM(X) = m and mxGetN(X) = n.
 *
 * Credit: Iskander Karibzhanov
 */
mxArray* cmpl2mat_real(doublecomplex *Z, int ldz, int m, int n) {
   int i, j, incz;
   double *xr;
   doublecomplex *zp;
   mxArray *X;

   X = mxCreateDoubleMatrix(m,n,mxREAL);
   xr = mxGetPr(X);
   zp = Z;
   incz = ldz-m;
   for (j = 0; j < n; j++) {
      for (i = 0; i < m; i++) {
         *xr++ = zp->r;
         zp++;
      }
      zp += incz;
   }
   return(X);
}
