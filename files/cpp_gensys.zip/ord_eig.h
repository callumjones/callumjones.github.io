#include "math.h"

logical order_eigs(doublecomplex* alpha, doublecomplex* beta) {
	
    double a = sqrt(alpha->r*alpha->r + alpha->i*alpha->i) ;
    double b = sqrt(beta->r*beta->r + beta->i*beta->i) ;
    
	if ((a / b) > 1) { return true ; }
	else { return false ; }
	
}