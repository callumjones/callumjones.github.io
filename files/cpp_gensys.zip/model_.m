% irelandsmats.m
%
% This file sets up the model of Ireland (2004) with long-rates
%
% Callum Jones
% callum.jones@nyu.edu

%% Parameters

beta   = 0.99 ;
psi    = 0.1 ;
omega  = 0.0617 ;
rho_r  = 1.0 ;
rho_pi = 0.3597 ;
rho_g  = 0.2536 ;
rho_x  = 0.0347 ;
rho_a  = 0.9;%947 ;
rho_e  = 0.9;%9625 ;
sig_a  = 0.0405 ;
sig_e  = 0.0012 ;
sig_z  = 0.0109 ;
sig_r  = 0.0031 ;
pi_target = (log(1.02)/4)+1 ;

lr = 120 ;

%% Model Setup

if lr==0
    n1 = 7 ; % Number of non-expectational variables
    n2 = 2 ; % Number of expectational variables
    s  = 1 ; % Number of leads of expectational variables
    k  = n2*s ;
    n  = n1 + n2 + k ; % Dimension of system
    l  = 4; % Number of shocks

    y  = 1 ; names{y,1} = 'y' ;
    g  = 2 ; names{g,1} = 'g' ;
    r  = 3 ; names{r,1} = 'r' ;
    rs = 4 ; names{rs,1} = 'rs' ;
    a  = 5 ; names{a,1} = 'a' ;
    e  = 6 ; names{e,1} = 'e' ;
    z  = 7 ; names{z,1} = 'z' ;

    pi = n1 + 1 ; names{pi,1} = 'pi' ;
    x  = n1 + 2 ; names{x,1} = 'x' ;

    E_pi = n1 + 3 ; names{E_pi,1} = 'E_pi' ;
    E_x  = n1 + 4 ; names{E_x,1} = 'E_x' ;
    
elseif lr>0
    n1 = 6 ; % Number of non-expectational variables
    n2 = 2 + lr ; % Number of expectational variables
    s  = 1 ; % Number of leads of expectational variables
    k  = n2*s ;
    n  = n1 + n2 + k ; % Dimension of system
    l  = 4; % Number of shocks

    y  = 1 ; names{y,1} = 'y' ;
    g  = 2 ; names{g,1} = 'g' ;
    rs = 3 ; names{rs,1} = 'rs' ;
    a  = 4 ; names{a,1} = 'a' ;
    e  = 5 ; names{e,1} = 'e' ;
    z  = 6 ; names{z,1} = 'z' ;

    pi = n1 + 1 ; names{pi,1} = 'pi' ;
    x  = n1 + 2 ; names{x,1} = 'x' ;
    r  = n1 + 3 ; names{r,1} = 'r' ;
    for i_ = 2:lr
        eval(['r',int2str(i_),'=',int2str(n1+2+i_),';']) ;
    end

    E_pi = n1 + n2 + 1 ; names{E_pi,1} = 'E_pi' ;
    E_x  = n1 + n2 + 2 ; names{E_x,1} = 'E_x' ;
    E_r  = n1 + n2 + 3 ; names{E_r,1} = 'E_x' ;
    for i_ = 2:lr
        eval(['E_r',int2str(i_),'=',int2str(n1+n2+2+i_),';']) ;
    end
end

eps_r = 1 ; names{eps_r,1} = 'eps_r' ;
eps_a = 2 ; names{eps_a,1} = 'eps_a' ;
eps_e = 3 ; names{eps_e,1} = 'eps_e' ;
eps_z = 4 ; names{eps_z,1} = 'eps_z' ;

% Allocate space for the matrices
GAMMA0t = zeros(n1+n2,n) ;
GAMMA1t = zeros(n1+n2,n) ;
PSIt    = zeros(n1+n2,l) ;
Ct      = zeros(n1+n2,1) ;

%% Model Equations

cr = 1;

%% Equation (1): IS Curve

% x_t - E_x_t + r_t - E_pi_t - (1 - omega)(1 - rho_a)a_t = 0

row.iscurve = cr ;

GAMMA0t(cr,x) = 1 ;
GAMMA0t(cr,E_x) = -1 ;
GAMMA0t(cr,r) = 1 ;
GAMMA0t(cr,E_pi) = -1 ;
GAMMA0t(cr,a) = - (1 - omega)*(1-rho_a) ;
%Ct(cr,1) = 0- log(pi_target) ;

cr = cr + 1 ;

%% Equation (2): Phillips Curve

% pi_t - beta E_pi_t - psi x_t + e_t = 0

row.phillipscurve = cr ;

GAMMA0t(cr,pi) = 1 ;
GAMMA0t(cr,E_pi) = -beta ;
GAMMA0t(cr,x) = -psi ;
GAMMA0t(cr,e) = 1 ;
%Ct(cr,1) = (1 - beta) * log(pi_target) ;

cr = cr + 1 ;

%% Equation (3): Policy Rule

% r_t - rho_pi pi_t - rho_g g_t - rho_x x_t = r_(t-1) + shock_r

row.policyrule = cr ;

GAMMA0t(cr,r) = 1 ;
GAMMA0t(cr,pi) = -rho_pi ;
GAMMA0t(cr,g) = -rho_g ;
GAMMA0t(cr,x) = -rho_x ;
GAMMA1t(cr,r) = rho_r ;
PSIt(cr,eps_r) = 1 ;
%Ct(cr,1) = -rho_pi * log(pi_target) ;

cr = cr + 1 ;

%% Equation (4): Shadow interest rate

% rs_t - rho_pi pi_t - rho_g g_t - rho_x x_t = r_(t-1) + shock_r

row.shadowrate = cr ;

GAMMA0t(cr,rs) = 1 ;
GAMMA0t(cr,pi) = -rho_pi ;
GAMMA0t(cr,g) = -rho_g ;
GAMMA0t(cr,x) = -rho_x ;
GAMMA1t(cr,r) = rho_r ;
PSIt(cr,eps_r) = 1 ;

cr = cr + 1 ;

%% Equation (4): Output Gap

% x_t - y_t + omega a_t = 0

row.outputgap = cr ;

GAMMA0t(cr,x) = 1 ;
GAMMA0t(cr,y) = -1 ;
GAMMA0t(cr,a) = omega ;

cr = cr + 1 ;

%% Equation (5): Output Growth

% g_t - y_t - z_t = - y_(t-1)

row.outputgrowth = cr ;

GAMMA0t(cr,g) = 1 ;
GAMMA0t(cr,y) = -1 ;
GAMMA0t(cr,z) = -1 ;
GAMMA1t(cr,y) = -1 ;

cr = cr + 1 ;

%% Equation (6): Demand Shock

% a_t = rho_a a_(t-1) + eps_a

row.demandshock = cr ;

GAMMA0t(cr,a) = 1 ;
GAMMA1t(cr,a) = rho_a ;
PSIt(cr,eps_a) = 1;

cr = cr + 1 ;

%% Equation (7): Cost Push Shock

% e_t = rho_e e_(t-1) + eps_e

row.costpushShock = cr ;

GAMMA0t(cr,e) = 1 ;
GAMMA1t(cr,e) = rho_e ;
PSIt(cr,eps_e) = 1;

cr = cr + 1 ;

%% Equation (8): Permanent Technology Shock

% z_t = eps_z

row.permTech = cr ;

GAMMA0t(cr,z) = 1 ;
PSIt(cr,eps_z) = 1;

cr = cr + 1 ;

%% Long-rates

% m R_{m,t} - R_{1,t} - (m-1) * E_t R_{{m-1},t+1} = 0

if lr
    r1 = r ;
    E_r1 = E_r ;
    
    for i_ = 2:lr
        eval(['row.lr',int2str(i_),' = cr ;']) ;

        eval(['GAMMA0t(cr,r', int2str(i_),') = i_;']);
        GAMMA0t(cr,r1) = -1 ;
        eval(['GAMMA0t(cr,E_r',int2str(i_-1),') = -(i_-1);']);

        cr = cr + 1 ;
    end
end

%% Add in Expectational Errors

GAM0 = [ GAMMA0t; [zeros(k,n1), eye(k), zeros(k,n2)] ];
GAM1 = [ GAMMA1t; [zeros(k,n1+n2),eye(k)] ];
PSI  = [ PSIt; zeros(k,l) ];
PPI  = [ zeros(n1+n2,k); eye(k) ];
C    = [ Ct; zeros(k,1) ];
